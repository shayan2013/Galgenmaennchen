// insgesamt 11 stufen
//window.onload=init();

var theWord;
var splitWord;
var canvas=document.getElementById("myCanvas");;
var ctx= canvas.getContext("2d");
var rowUp;
var rowDown;
var consist=false;
var x=[];
var palyer1;
var player2;
var player1score=0;
var player2score=0;
var mod;
var j=0;
var colorsRed=["#FFA500","#FF9700","#FF8A00","#FF7C00","#FF6E00","#FF6000","#FF5300","#FF4500","#FF3700","#FF2900","#FF1C00","#FF0E00","#FF0000"];
var colorsGreen=["#ADFF2F","#9FFF2B","#90FF27","#82FF23","#73FF1F","#65FF1B","#57FF18","#48FF14","#3AFF10","#2BFF0C","#1DFF08","#0EFF04","#00FF00"];

canvas.width = window.innerWidth;
canvas.height = window.innerHeight/2;
ctx.lineWidth=5;


function init(){

	document.getElementById("theWord").style.display="none";
	document.getElementById("theGame").style.display="none";
	document.getElementById("nextRound").style.display="none";
	document.getElementById("score").style.display="none";


}

function start(){

	player1=document.getElementById("player1").value.toUpperCase() || "PLAYER 1";
	player2=document.getElementById("player2").value.toUpperCase() || "PLAYER 2";

	mod=player1;

	document.getElementById("start").style.display="none";

	confirm (mod +" enter a word.");

	document.getElementById("theWord").style.display="block";

}


function firstClick(){

	j=0;
	ctx.fillStyle="white";
	ctx.fillRect(0,0,canvas.width,canvas.height);

	theWord= document.getElementById("myInput").value.toUpperCase();

	if(theWord.length<3 || validate(theWord)==false){
				document.getElementById("myInput").value="";
				//theWord="";

		return alert ("At least 3 characters. No Numbers. No Symbols. No Spaces!!! Try it again");
	}else{

	splitWord=theWord.split("");
	if (mod==player1){ mod=player2;}
	else {mod=player1 ;}
	
	document.getElementById("theWord").style.display="none";
	document.getElementById("theGame").style.display="block";

	confirm ("The word is "+splitWord.length+" characters long. It's "+mod+"'s turn. Press OK and hand over!!!");
	/*document.getElementById("myInput").style.display="none";
	document.getElementById("myButton").style.display="none";*/

	document.getElementById("score").style.display="block";
	document.getElementById("p1").innerHTML=player1;
	document.getElementById("p1s").innerHTML=player1score;
	document.getElementById("p2").innerHTML=player2;
	document.getElementById("p2s").innerHTML=player2score;



	rowUp=document.getElementById("up");
	rowDown=document.getElementById("down");

	for (var i =0; i < splitWord.length; i++) {
		rowUp.insertCell(i);
		rowDown.insertCell(i);
		rowUp.childNodes[i].innerHTML="";
		rowDown.childNodes[i].innerHTML="";
		rowDown.childNodes[i].style.backgroundColor=colorsRed[colorsRed.length-splitWord.length+i];
		rowUp.childNodes[i].style.backgroundColor=colorsGreen[colorsGreen.length-splitWord.length+i];
	};

	document.getElementById("uInput").style.display="inline";
	document.getElementById("uButton").style.display="inline";
	
	/*canvas = document.getElementById("myCanvas");
	ctx = canvas.getContext("2d");*/
	}
	
}


//var i=0;
	
function nextLevel(){

	//playerScore();
	
	var suggestion=document.getElementById("uInput").value.toUpperCase();

	if (validate(suggestion)==false){
		document.getElementById("myInput").value="";
				//theWord="";

		return alert ("No Numbers. No Symbols. No Spaces!!! Try it again");

	}else{

	for (var i=0; i<splitWord.length; i++){

		if (suggestion===splitWord[i]){

		rowUp.childNodes[i].innerHTML=suggestion;
		x[i]=suggestion;
		if (x.toString()===splitWord.toString()){
			if (mod==player1) player1score+=1;
			if (mod==player2) player2score+=1;
//playerScore();
			ctx.font = "60px Gabriola";
	ctx.fillStyle = "green";
	ctx.textAlign = "center";
	ctx.fillText("YOU WIN", canvas.width/2, canvas.height/2);
	document.getElementById("p1s").innerHTML=player1score;
	document.getElementById("p2s").innerHTML=player2score;
	document.getElementById("uInput").style.display="none";
	document.getElementById("uButton").style.display="none";
			//drawing(12);
			
	document.getElementById("nextRound").style.display="inline";

		}
	}

	}

	/*for (var t=0; t<splitWord.length; t++){
		var tableValue=rowUp.childNodes[i].value;
		alert(tableValue);
		x.push(tableValue);
	}
	if (splitWord==x){
		alert("yoohoo");
	}*/

	//console.log(x);

	if (splitWord.indexOf(suggestion)== -1){
		
		rowDown.childNodes[j].innerHTML=suggestion;
		j++;
		drawing(j);
		if (j==splitWord.length){
			for(var xj=j+1; xj<=11; xj++){
			drawing(xj);
			}
			//j=0;
		}
	}

	
document.getElementById("uInput").value="";
	//document.getElementById("myForm").reset();
}
}


function drawing(number){
	switch (number){
		case 1:
		drawOne();
		break;
		case 2:
		drawTwo();
		break;
		case 3:
		drawThree();
		break;
		case 4:
		drawFour();
		break;
		case 5:
		drawFive();
		break;
		case 6:
		drawSix();
		break;
		case 7:
		drawSeven();
		break;
		case 8:
		drawEight();
		break;
		case 9:
		drawNine();
		break;
		case 10:
		drawTen();
		break;
		case 11:
		drawEleven();
		break;

	}


}
	
	



function drawOne(){
ctx.beginPath();
	ctx.moveTo(canvas.width*1/3,canvas.height*9/10);
	ctx.lineTo(canvas.width*2/3,canvas.height*9/10);
	ctx.stroke();

}

function drawTwo(){
ctx.beginPath();
	ctx.moveTo(canvas.width*1/2,canvas.height*9/10);
	ctx.lineTo(canvas.width*1/2,canvas.height*1/10);
	ctx.stroke();

}

function drawThree(){
ctx.beginPath();
	ctx.moveTo(canvas.width*1/2,canvas.height*1/10);
	ctx.lineTo(canvas.width*3/4,canvas.height*1/10);
	ctx.stroke();

}

function drawFour(){
ctx.beginPath();
	ctx.moveTo(canvas.width*1/2,canvas.height*3/10);
	ctx.lineTo(canvas.width*6/10,canvas.height*1/10);
	ctx.stroke();

}

function drawFive(){
ctx.beginPath();
	ctx.moveTo(canvas.width*3/4,canvas.height*1/10);
	ctx.lineTo(canvas.width*3/4,canvas.height*2/10);
	ctx.stroke();

}

function drawSix(){
ctx.beginPath();
	ctx.beginPath();
	ctx.arc(canvas.width*3/4,canvas.height*3/10,canvas.height*3/10-canvas.height*2/10,0,2*Math.PI);
	ctx.stroke();

}

function drawSeven(){
ctx.beginPath();
	ctx.moveTo(canvas.width*3/4,canvas.height*3/10+canvas.height*3/10-canvas.height*2/10);
	ctx.lineTo(canvas.width*3/4,canvas.height*6/10);
	ctx.stroke();

}

function drawEight(){
ctx.beginPath();
	ctx.moveTo(canvas.width*3/4,canvas.height*4/9);
	ctx.lineTo(canvas.width*11/16,canvas.height*6/10);
	ctx.stroke();

}

function drawNine(){
ctx.beginPath();
	ctx.moveTo(canvas.width*3/4,canvas.height*4/9);
	ctx.lineTo(canvas.width*13/16,canvas.height*6/10);
	ctx.stroke();

}

function drawTen(){
ctx.beginPath();
	ctx.moveTo(canvas.width*3/4,canvas.height*6/10);
	ctx.lineTo(canvas.width*13/18,canvas.height*8/10);
	ctx.stroke();

}

function drawEleven(){
ctx.beginPath();
	ctx.moveTo(canvas.width*3/4,canvas.height*6/10);
	ctx.lineTo(canvas.width*14/18,canvas.height*8/10);
	ctx.stroke();
	ctx.font = "60px Gabriola";
	ctx.fillStyle = "red";
	ctx.textAlign = "center";
	ctx.fillText("YOU LOSE", canvas.width/2, canvas.height/2);
	document.getElementById("uInput").style.display="none";
	document.getElementById("uButton").style.display="none";
	confirm("It was "+theWord);
	document.getElementById("nextRound").style.display="inline";
	//j=0;


}

function nextRound(){

	ctx.clearRect(0, 0, canvas.width, canvas.height);
	x=[];
	for (var i =0; i < splitWord.length; i++) {
		rowUp.deleteCell(0);
		rowDown.deleteCell(0);
		/*rowUp.childNodes[i].innerHTML="";
		rowDown.childNodes[i].innerHTML="";*/
	};
	document.getElementById("myInput").value="";
	document.getElementById("nextRound").style.display="none";
	document.getElementById("theGame").style.display="none";
	confirm (mod+" enter a Word");
	
	
	document.getElementById("theWord").style.display="block";

}

/*function playerScore(){
	ctx.clearRect(0, 0, canvas.width, 30);
	ctx.beginPath();
	ctx.font = "20px Comic Sans MS";
	ctx.fillStyle = "black";
	ctx.fillText(player1+" = "+player1score+" / "+player2+" = "+player2score,(canvas.width/canvas.width)+10, (canvas.height/canvas.height)+20);
	

}*/

function validate(strValue) {
  var objRegExp  = /^[A-Za-z\u00C0-\u00ff]+$/;
  return objRegExp.test(strValue);
}


//window.onresize=function(){console.log("arararararara");}