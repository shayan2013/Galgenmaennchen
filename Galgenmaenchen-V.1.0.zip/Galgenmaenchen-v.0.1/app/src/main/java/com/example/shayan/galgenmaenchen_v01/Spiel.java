package com.example.shayan.galgenmaenchen_v01;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Random;

public class Spiel extends ActionBarActivity {

    TextView themaText, wortFeld, fehlerText, myWort, rundeText, rekordText;
    Button backButton;
    ImageView imageview;
    private int fehler = 0;
    private int runde = 1;
    private int rekord = 0;




    String[] laender = {"DEUTSCHLAND", "FRANKREICH", "IRAN", "BELGIEN", "USA",
            "JAPAN", "CHINA", "RUSSLAND", "HOLLAND", "DÄNEMARK", "POLEN",
            "KUBA", "COLUMBIEN", "SPANIEN", "ITALIEN", "SCHWEIZ"};
    String[] tiere = {"KANINCHEN", "SCHWEIN", "PFERD", "ELEFANT", "KATZE",
            "HUND", "ENTE", "FISCH", "FROSCH", "REH"};

    String wort = "";
    String auswahl;
    int wortLength;
    char[] wortArray;
    private String[] worttest;

 //   public char[] wortMacher(){
 //       String wort = laender[randomZahl(laender.length)];
        
//}

    //findWord
    public void findWord(String auswahl){
        if(auswahl.equals("Länder")){
            wort = laender[randomZahl(laender.length)];
        }else if(auswahl.equals("Tiere")){
            wort = tiere[randomZahl(tiere.length)];
        }

        wortLength = wort.length();
        wortArray = wort.toCharArray();
        worttest = new String[wortLength];
        myWort.setText(wort);
        fehlerText.setText(String.valueOf(getFehler()));
        rundeText.setText(String.valueOf(getRunde()));
        rekordText.setText(String.valueOf(getRekord()));
        for (int r = 0; r < wortLength; r++){
            setWortFeld(r, '?');
        }

        wortFeld.setText(Arrays.toString(getWortFeld()));
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spiel);
        Bundle spielData = getIntent().getExtras();
        backButton = (Button)findViewById(R.id.backButton);

        if (spielData==null){
            return;
        }

        themaText = (TextView)findViewById(R.id.themaText);
        wortFeld = (TextView)findViewById(R.id.wort);
        fehlerText = (TextView)findViewById(R.id.fehler);
        myWort = (TextView)findViewById(R.id.myWort);
        rundeText = (TextView) findViewById(R.id.runde);
        rekordText = (TextView) findViewById(R.id.rekord);
        auswahl = spielData.getString("auswahl");
        themaText.setText(auswahl);
        setAuswahl(auswahl);

        setFehler(0);
        setRunde(1);
        setRekord(0);
        findWord(getAuswahl());
        showImage();


    }


    public void showImage(){

        String imageZahl = String.valueOf(getFehler());
        if(getFehler() < 5){
            String uri = "@drawable/g" + imageZahl;  // where myresource.png is the file
            // extension removed from the String

            int imageResource = getResources().getIdentifier(uri, null, getPackageName());

            imageview= (ImageView)findViewById(R.id.imageView);
            Drawable res = getResources().getDrawable(imageResource);
            imageview.setImageDrawable(res);
        }else {
            wortFeld.setText(wort);
            String uri = "@drawable/g" + imageZahl;  // where myresource.png is the file
            // extension removed from the String

            int imageResource = getResources().getIdentifier(uri, null, getPackageName());

            imageview= (ImageView)findViewById(R.id.imageView);
            Drawable res = getResources().getDrawable(imageResource);
            imageview.setImageDrawable(res);
            freeze(5000);
            Intent in = new Intent(this, Home.class);
            startActivity(in);

        }

    }

    //random-zahl
    public int randomZahl(int grenzzahl){
        Random r = new Random();
        int myRandomZahl = r.nextInt(grenzzahl);
        return myRandomZahl;
    }

    //freez wait
    public void freeze(int freeztime){
        long futureTime = System.currentTimeMillis() + freeztime;
        while (System.currentTimeMillis() < futureTime){
            synchronized (this){
                try{
                    wait(futureTime - System.currentTimeMillis());
                }catch(Exception e) {}

            }
        }
    }

    //back-button-clicked
    public void backClicked(View view){
        Intent in = new Intent(this, NeuesSpiel.class);
        startActivity(in);

    }

    //test Buchstaben
    public boolean testClass(char chartest){
        int n = 0;
        for(int i = 0; i < wortLength; i++){
            if(wortArray[i]==(chartest)){
                n++;
                setWortFeld(i, chartest);
            }
        }
        if(n==0){
            return false;
        }

        return true;

    }

    //count recorde
    private int rekordRechner(){
        int neuRekord = 10;
        neuRekord -= getFehler();
        neuRekord += getRekord();
        return neuRekord;
    }

    //convert string array to string
    private static String convertStringArrayToString(String[] strArr) {
        StringBuilder sb = new StringBuilder();
        for(String str : strArr) sb.append(str);
        return sb.toString();
    }

    //win test
    public boolean winTest(String[] arrayWort){
        String str1 = convertStringArrayToString(arrayWort);

        myWort.setText(str1);
        if (str1.equals(wort)){
            return true;
        }
        return false;
    }


    //neue Runde
    public void newRund(){
        setRunde((getRunde())+1);
        setRekord(rekordRechner());
        setFehler(0);
        showImage();
        findWord(getAuswahl());

    }


    //setter & getter
    public void setAuswahl(String auswahl){
        this.auswahl = auswahl;
    }
    public String getAuswahl(){
        return auswahl;
    }

    public void setFehler(int fehler) {
        this.fehler = fehler;
    }

    public int getFehler() {

        return fehler;
    }

    public void setRunde(int runde){
        this.runde = runde;
    }

    public int getRunde(){
        return runde;
    }

    public void setRekord(int rekord){
        this.rekord = rekord;
    }

    public int getRekord(){
        return rekord;
    }


    public void setWortFeld(int i, char n) {
        String ns = String.valueOf(n);
        worttest[i] = ns;
    }

    public String[] getWortFeld() {

        return worttest;
    }

    //falsche Eingabe
    public void falscheEingabe(){
        setFehler(getFehler() + 1);
        fehlerText.setText(String.valueOf(getFehler()));
        showImage();
    }

    //test True
    public void testTrue(){
        String name = Arrays.toString(getWortFeld());
        wortFeld.setText(name);
        if(winTest(getWortFeld())){
            newRund();
        }
    }



    //Buchstaben
    public void aC(View view){
        if(testClass('A')){
            testTrue();
        }else{
            falscheEingabe();
        }
    }

    public void bC(View view){
        if(testClass('B')){
            testTrue();
        }else{
            falscheEingabe();
        }
    }

    public void cC(View view){
        if(testClass('C')){
            testTrue();
        }else{
            falscheEingabe();
        }
    }

    public void dC(View view){
        if(testClass('D')){
            testTrue();
        }else{
            falscheEingabe();
        }
    }

    public void eC(View view){
        if(testClass('E')){
            testTrue();
        }else{
            falscheEingabe();
        }
    }

    public void fC(View view){
        if(testClass('F')){
            testTrue();
        }else{
            falscheEingabe();
        }
    }

    public void gC(View view){
        if(testClass('G')){
            testTrue();
        }else{
            falscheEingabe();
        }
    }

    public void hC(View view){
        if(testClass('H')){
            testTrue();
        }else{
            falscheEingabe();
        }
    }

    public void iC(View view){
        if(testClass('I')){
            testTrue();
        }else{
            falscheEingabe();
        }
    }

    public void jC(View view){
        if(testClass('J')){
            testTrue();
        }else{
            falscheEingabe();
        }
    }

    public void kC(View view){
        if(testClass('K')){
            testTrue();
        }else{
            falscheEingabe();
        }
    }

    public void lC(View view){
        if(testClass('L')){
            testTrue();
        }else{
            falscheEingabe();
        }
    }

    public void mC(View view){
        if(testClass('M')){
            testTrue();
        }else{
            falscheEingabe();
        }
    }

    public void nC(View view){
        if(testClass('N')){
            testTrue();
        }else{
            falscheEingabe();
        }
    }

    public void oC(View view){
        if(testClass('O')){
            testTrue();
        }else{
            falscheEingabe();
        }
    }

    public void pC(View view){
        if(testClass('P')){
            testTrue();
        }else{
            falscheEingabe();
        }
    }

    public void qC(View view){
        if(testClass('Q')){
            testTrue();
        }else{
            falscheEingabe();
        }
    }

    public void rC(View view){
        if(testClass('R')){
            testTrue();
        }else{
            falscheEingabe();
        }
    }

    public void sC(View view){
        if(testClass('S')){
            testTrue();
        }else{
            falscheEingabe();
        }
    }

    public void tC(View view){
        if(testClass('T')){
            testTrue();
        }else{
            falscheEingabe();
        }
    }

    public void uC(View view){
        if(testClass('U')){
            testTrue();
        }else{
            falscheEingabe();
        }
    }

    public void vC(View view){
        if(testClass('V')){
            testTrue();
        }else{
            falscheEingabe();
        }
    }

    public void wC(View view){
        if(testClass('W')){
            testTrue();
        }else{
            falscheEingabe();
        }
    }

    public void xC(View view){
        if(testClass('X')){
            testTrue();
        }else{
            falscheEingabe();
        }
    }

    public void yC(View view){
        if(testClass('Y')){
            testTrue();
        }else{
            falscheEingabe();
        }
    }

    public void zC(View view){
        if(testClass('Z')){
            testTrue();
        }else{
            falscheEingabe();
        }
    }

    public void äC(View view){
        if(testClass('Ä')){
            testTrue();
        }else{
            falscheEingabe();
        }
    }

    public void öC(View view){
        if(testClass('Ö')){
            testTrue();
        }else{
            falscheEingabe();
        }
    }

    public void üC(View view){
        if(testClass('Ü')){
            testTrue();
        }else{
            falscheEingabe();
        }
    }

    public void ßC(View view){
        if(testClass('ß')){
            testTrue();
        }else{
            falscheEingabe();
        }
    }






}
