package com.example.shayan.galgenmaenchen_v01;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;

public class NeuesSpiel extends ActionBarActivity {

    static String auswahl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_neues_spiel);
    }

    public void firstClick(View view){
        Intent in = new Intent(this, Spiel.class);
        auswahl = "Länder";
        in.putExtra("auswahl", auswahl);
        startActivity(in);

    }

    public void secClicked(View view){
        Intent in = new Intent(this, Spiel.class);
        auswahl = "Tiere";
        in.putExtra("auswahl", auswahl);
        startActivity(in);
    }

}
